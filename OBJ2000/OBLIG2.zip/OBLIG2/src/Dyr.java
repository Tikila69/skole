import java.util.Date;

public class Dyr {

    String kjønn;
    Double lengde;
    Double vekt;
    String dato;
    String sted;

    public Dyr(String kjønn, Double lengde, Double vekt, String dato, String sted) {
        super();
        this.kjønn = kjønn;
        this.lengde = lengde;
        this.vekt = vekt;
        this.dato = dato;
        this.sted = sted;
    }

}
