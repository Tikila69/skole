public class GjenfangstHare {
}
