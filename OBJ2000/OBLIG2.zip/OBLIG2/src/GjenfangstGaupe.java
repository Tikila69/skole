public class GjenfangstGaupe {
}
