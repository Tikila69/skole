package Sawkins.Diktgenerator;

public class Diktprogram {
    public static void main(String[] args) {
        Grensesnitt grensesnitt = new Grensesnitt();
        grensesnitt.hovedmeny();
    }
}
